<?php
// Database connection details
$servername = "localhost"; // Change this if your database server is not local
$username = "root";        // Your database username
$password = "";            // Your database password
$dbname = "Admin";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Capture form data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $subject = $_POST['subject'];

    // Check if faculty already exists
    $checkSql = "SELECT * FROM faculty WHERE email = ? OR name = ?";
    $stmt = $conn->prepare($checkSql);
    $stmt->bind_param("ss", $email, $name);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // If Faculty already exists
        echo "<script>alert('Faculty already registered!');</script>";
        echo "<script>window.location.href = 'dashboard.html';</script>"; // Redirect back to dashboard
    } else {

        // SQL query to insert data into the faculty table
        $insertSql = "INSERT INTO faculty (name, email, password, subject) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($insertSql);
        $stmt->bind_param("ssss", $name, $email, $password, $subject);

        if ($stmt->execute()) {
            echo "<script>alert('Faculty registered successfully!');</script>";
            echo "<script>window.location.href = 'dashboard.html';</script>"; // Redirect back to dashboard
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
            echo "<script>window.location.href = 'dashboard.html';</script>"; // Redirect back to dashboard
        }
    }

    $stmt->close();
}

// Close the connection
$conn->close();
?>