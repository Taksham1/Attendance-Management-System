<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get email and password from the form
$email = $_POST['u_name'];
$password = $_POST['u_pass'];

// Prepare and bind SQL statement
$stmt = $conn->prepare("SELECT * FROM faculty WHERE email = ? AND password = ?");
$stmt->bind_param("ss", $email, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // User found - display success popup and redirect
    echo "<script>
            alert('Login successful!');
            window.location.href = 'user_dashboard.html';
          </script>";
} else {
    // User not found - display error popup and redirect back to login page
    echo "<script>
            alert('Error: User Not Found or Invalid ID and Password!');
            window.location.href = 'Ulogin.html';
          </script>";
}

$stmt->close();
$conn->close();
?>