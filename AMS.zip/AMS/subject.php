<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "Admin");

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture form data
    $subject_name = $_POST['subject-name'];
    $course_name = $_POST['course-name'];

    // Prepare and bind an SQL statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO subjects (subject_name, course_name) VALUES (?, ?)");
    $stmt->bind_param("ss", $subject_name, $course_name);

        if ($stmt->execute()) {
            // Popup alert for successful registration and redirection to dashboard
            echo "<script>alert('Subject registered successfully!');</script>";
            echo "<script>window.location.href = 'dashboard.html';</script>";
        } else {
            // Popup alert for insertion error and redirection to dashboard
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
            echo "<script>window.location.href = 'dashboard.html';</script>";
        }
    $stmt->close();
}

// Close the connection
$conn->close();
?>