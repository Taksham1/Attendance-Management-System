<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BTECH Students</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            color: #333;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        h1 {
            font-size: 2em;
            margin: 20px;
            color: #1e3d59;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 100%;
        }

        label {
            font-size: 1.2em;
            color: #1e3d59;
        }

        input[type="date"] {
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: calc(100% - 24px);
            box-sizing: border-box;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
            font-size: 1em;
            background-color: #fefefe;
        }

        th {
            background-color: #1e3d59;
            color: #fff;
            padding: 15px;
            font-size: 1.2em;
        }

        td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }

        tr:nth-child(even) {
            background-color: #f4f4f4;
        }

        tr:hover {
            background-color: #e8f4fa;
            cursor: pointer;
        }

        button {
            padding: 12px 20px;
            background-color: #1e3d59;
            color: #fff;
            font-size: 1em;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px;
        }

        button:hover {
            background-color: #87cefa;
        }

        @media (max-width: 768px) {
            h1 {
                font-size: 1.5em;
            }

            table {
                font-size: 0.9em;
            }

            th, td {
                padding: 10px;
            }

            input[type="date"] {
                font-size: 1em;
            }

            button {
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <h1>Student Attendance Form</h1>
    <form method="POST">
        <label for="attendance_date">Select Date:</label>
        <input type="date" id="attendance_date" name="attendance_date" required><br><br>
        <table>
		<script>
    document.addEventListener("DOMContentLoaded", () => {
        const attendanceDateInput = document.getElementById("attendance_date");

        // Disable Sundays and limit the selectable date range
        attendanceDateInput.addEventListener("input", () => {
            const selectedDate = new Date(attendanceDateInput.value);
            const currentDate = new Date();
            
            // Calculate seven days before the current date
            const sevenDaysAgo = new Date();
            sevenDaysAgo.setDate(currentDate.getDate() - 7);

            // Ensure Sunday is blocked (0 corresponds to Sunday in JavaScript Date object)
            if (selectedDate.getDay() === 0) {
                alert("Attendance cannot be marked on Sundays.");
                attendanceDateInput.value = ""; // Reset the input
            }

            // Ensure the selected date is within the allowed range
            if (selectedDate > currentDate || selectedDate < sevenDaysAgo) {
                alert("You can only select the current date or dates up to 7 days prior.");
                attendanceDateInput.value = ""; // Reset the input
            }
        });

        // Set initial attributes for allowed date range
        const currentDate = new Date().toISOString().split("T")[0];
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(new Date().getDate() - 7);
        const sevenDaysAgoFormatted = sevenDaysAgo.toISOString().split("T")[0];

        attendanceDateInput.setAttribute("max", currentDate);
        attendanceDateInput.setAttribute("min", sevenDaysAgoFormatted);
    });
</script>s
            <thead>
                <tr>
                    <th>Roll Number</th>
                    <th>Name</th>
                    <th>Attendance</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Database connection details
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "user";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetching data from the 'bca' table
                $sql = "SELECT * FROM bca"; // Ensure the table 'bca' exists and has these columns
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>" .($row['roll_number']) . "</td>
                                <td>" .($row['name']) . "</td>
                                <td><input type='checkbox' name='attendance[]' value='" . ($row['roll_number']) . "'></td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No students found</td></tr>";
                }

                $conn->close();
                ?>
            </tbody>
        </table>
        <button type="submit">Submit Attendance</button>
    </form>

    <?php
    // Backend  for Attendance
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database connection details
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "attendance";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $attendance_date = $_POST['attendance_date'];
        $attendance_data = isset($_POST['attendance']) ? $_POST['attendance'] : [];

        // Format the table name using the selected date
        $table_name = "BTECH_" . str_replace('-', '_', $attendance_date);

        // Create a table for the selected date if it doesn't exist
        $create_table_sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id INT AUTO_INCREMENT PRIMARY KEY,
            roll_number VARCHAR(50),
            status VARCHAR(10)
        )";

        if ($conn->query($create_table_sql) === TRUE) {
            echo "<script>alert('Table $table_name created successfully or already exists.');</script>";
        } else {
            die("<script>alert('Error creating table: " . $conn->error . "');</script>");
        }

        if (!empty($attendance_data)) {
            $stmt = $conn->prepare("INSERT INTO $table_name (roll_number, status) VALUES (?, ?)");
            $status = 'Present';
            foreach ($attendance_data as $roll_number) {
                $stmt->bind_param("ss", $roll_number, $status);
                $stmt->execute();
            }
            $stmt->close();
            echo "<script>alert('Attendance marked successfully!');</script>";
        } else {
            echo "<script>alert('No attendance selected!');</script>";
        }

        $conn->close();
    }
    ?>
</body>
</html>