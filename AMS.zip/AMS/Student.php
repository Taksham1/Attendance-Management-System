<?php
// Database connection
$servername = "localhost";
$username = "root"; // Update with your DB username
$password = "";     // Update with your DB password
$dbname = "user"; // Update with your DB name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$rollNumber = $_POST['roll-number'];
$course = $_POST['course-name'];

switch ($course) {
    case 'bca':
        $table = 'bca';
        break;
    case 'bba':
        $table = 'bba';
        break;
    case 'btech':
        $table = 'btech';
        break;
    default:
        die("Invalid course selected");
}

$sql = "INSERT INTO $table (name, roll_number) VALUES ('$name', '$rollNumber')";

if ($conn->query($sql) === TRUE) {
    echo "<script>
        alert('Student registered successfully in $course table.');
        window.location.href = document.referrer; // Redirect to the previous page
    </script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>