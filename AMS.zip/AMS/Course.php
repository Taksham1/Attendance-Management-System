<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Admin";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get data from the form
$courseName = $_POST['course-name'];
$courseDuration = $_POST['course-duration'];

// Prepare and bind SQL statement to insert data
$stmt = $conn->prepare("INSERT INTO courses (course_name, course_duration) VALUES (?, ?)");
$stmt->bind_param("ss", $courseName, $courseDuration);
  if ($stmt->execute()) {
            echo "<script>alert('New Course Added successfully!');</script>";
            echo "<script>window.location.href = 'dashboard.html';</script>"; // Redirect back to dashboard
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
            echo "<script>window.location.href = 'dashboard.html';</script>"; // Redirect back to dashboard
        }


$stmt->close();
$conn->close();
?>
