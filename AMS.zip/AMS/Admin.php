<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['Ad_name']; // Get username from the form
    $password = $_POST['A_pass']; // Get password from the form

    // Check username and password
    if ($username === "Admin1" && $password === "0000") {
        // Show success popup and redirect to Admin_home.html
        echo "<script>
                alert('Login successful!');
                window.location.href = 'Admin_home.html';
              </script>";
    } else {
        // Show error popup and redirect back to Adlogin.html
        echo "<script>
                alert('Error: User Not Found or Invalid ID and Password!');
                window.location.href = 'Adlogin.html';
              </script>";
    }
}
?>